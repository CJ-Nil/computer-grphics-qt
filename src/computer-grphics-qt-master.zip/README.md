BCSEIII-CompGraph
