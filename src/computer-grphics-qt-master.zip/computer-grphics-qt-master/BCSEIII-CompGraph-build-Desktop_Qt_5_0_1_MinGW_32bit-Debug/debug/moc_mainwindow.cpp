/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.0.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.0.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[34];
    char stringdata[596];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_MainWindow_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10),
QT_MOC_LITERAL(1, 11, 24),
QT_MOC_LITERAL(2, 36, 0),
QT_MOC_LITERAL(3, 37, 7),
QT_MOC_LITERAL(4, 45, 12),
QT_MOC_LITERAL(5, 58, 25),
QT_MOC_LITERAL(6, 84, 4),
QT_MOC_LITERAL(7, 89, 25),
QT_MOC_LITERAL(8, 115, 16),
QT_MOC_LITERAL(9, 132, 17),
QT_MOC_LITERAL(10, 150, 17),
QT_MOC_LITERAL(11, 168, 19),
QT_MOC_LITERAL(12, 188, 19),
QT_MOC_LITERAL(13, 208, 19),
QT_MOC_LITERAL(14, 228, 15),
QT_MOC_LITERAL(15, 244, 17),
QT_MOC_LITERAL(16, 262, 17),
QT_MOC_LITERAL(17, 280, 17),
QT_MOC_LITERAL(18, 298, 26),
QT_MOC_LITERAL(19, 325, 28),
QT_MOC_LITERAL(20, 354, 13),
QT_MOC_LITERAL(21, 368, 1),
QT_MOC_LITERAL(22, 370, 13),
QT_MOC_LITERAL(23, 384, 1),
QT_MOC_LITERAL(24, 386, 13),
QT_MOC_LITERAL(25, 400, 18),
QT_MOC_LITERAL(26, 419, 22),
QT_MOC_LITERAL(27, 442, 23),
QT_MOC_LITERAL(28, 466, 23),
QT_MOC_LITERAL(29, 490, 13),
QT_MOC_LITERAL(30, 504, 23),
QT_MOC_LITERAL(31, 528, 23),
QT_MOC_LITERAL(32, 552, 22),
QT_MOC_LITERAL(33, 575, 19)
    },
    "MainWindow\0showCurrentMousePosition\0"
    "\0QPoint&\0mousePressed\0on_show_axes_stateChanged\0"
    "arg1\0on_grid_size_valueChanged\0"
    "on_reset_clicked\0on_set_p1_clicked\0"
    "on_set_p2_clicked\0on_unset_p2_clicked\0"
    "on_unset_p1_clicked\0on_unset_np_clicked\0"
    "on_draw_clicked\0on_draw_2_clicked\0"
    "on_set_np_clicked\0on_draw_3_clicked\0"
    "on_radius_box_valueChanged\0"
    "on_radius_box_2_valueChanged\0set_draw_type\0"
    "t\0set_color_box\0c\0set_fill_type\0"
    "set_transform_type\0on_transform_b_clicked\0"
    "on_scale_x_valueChanged\0on_scale_y_valueChanged\0"
    "set_clip_type\0on_window_point_clicked\0"
    "on_unset_window_clicked\0on_draw_window_clicked\0"
    "on_clipping_clicked\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      28,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,  154,    2, 0x0a,
       4,    0,  157,    2, 0x0a,
       5,    1,  158,    2, 0x08,
       7,    1,  161,    2, 0x08,
       8,    0,  164,    2, 0x08,
       9,    0,  165,    2, 0x08,
      10,    0,  166,    2, 0x08,
      11,    0,  167,    2, 0x08,
      12,    0,  168,    2, 0x08,
      13,    0,  169,    2, 0x08,
      14,    0,  170,    2, 0x08,
      15,    0,  171,    2, 0x08,
      16,    0,  172,    2, 0x08,
      17,    0,  173,    2, 0x08,
      18,    1,  174,    2, 0x08,
      19,    1,  177,    2, 0x08,
      20,    1,  180,    2, 0x08,
      22,    1,  183,    2, 0x08,
      24,    1,  186,    2, 0x08,
      25,    1,  189,    2, 0x08,
      26,    0,  192,    2, 0x08,
      27,    1,  193,    2, 0x08,
      28,    1,  196,    2, 0x08,
      29,    1,  199,    2, 0x08,
      30,    0,  202,    2, 0x08,
      31,    0,  203,    2, 0x08,
      32,    0,  204,    2, 0x08,
      33,    0,  205,    2, 0x08,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    6,
    QMetaType::Void, QMetaType::Int,    6,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    6,
    QMetaType::Void, QMetaType::Int,    6,
    QMetaType::Void, QMetaType::QString,   21,
    QMetaType::Void, QMetaType::QString,   23,
    QMetaType::Void, QMetaType::QString,   21,
    QMetaType::Void, QMetaType::QString,   21,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Double,    6,
    QMetaType::Void, QMetaType::Double,    6,
    QMetaType::Void, QMetaType::QString,   21,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        switch (_id) {
        case 0: _t->showCurrentMousePosition((*reinterpret_cast< QPoint(*)>(_a[1]))); break;
        case 1: _t->mousePressed(); break;
        case 2: _t->on_show_axes_stateChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->on_grid_size_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->on_reset_clicked(); break;
        case 5: _t->on_set_p1_clicked(); break;
        case 6: _t->on_set_p2_clicked(); break;
        case 7: _t->on_unset_p2_clicked(); break;
        case 8: _t->on_unset_p1_clicked(); break;
        case 9: _t->on_unset_np_clicked(); break;
        case 10: _t->on_draw_clicked(); break;
        case 11: _t->on_draw_2_clicked(); break;
        case 12: _t->on_set_np_clicked(); break;
        case 13: _t->on_draw_3_clicked(); break;
        case 14: _t->on_radius_box_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 15: _t->on_radius_box_2_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 16: _t->set_draw_type((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 17: _t->set_color_box((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 18: _t->set_fill_type((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 19: _t->set_transform_type((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 20: _t->on_transform_b_clicked(); break;
        case 21: _t->on_scale_x_valueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 22: _t->on_scale_y_valueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 23: _t->set_clip_type((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 24: _t->on_window_point_clicked(); break;
        case 25: _t->on_unset_window_clicked(); break;
        case 26: _t->on_draw_window_clicked(); break;
        case 27: _t->on_clipping_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, 0, 0}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 28)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 28;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 28)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 28;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
