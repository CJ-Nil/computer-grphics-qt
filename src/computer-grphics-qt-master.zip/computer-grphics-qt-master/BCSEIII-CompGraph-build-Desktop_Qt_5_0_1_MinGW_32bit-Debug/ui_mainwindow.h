/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.0.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>
#include <my_label.h>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QFrame *line;
    QPushButton *draw;
    QPushButton *reset;
    my_label *frame;
    QCheckBox *show_axes;
    QLabel *label;
    QLabel *mouse_position;
    QLabel *label_2;
    QLabel *locked_position;
    QPushButton *set_p1;
    QPushButton *set_p2;
    QLabel *p1_label;
    QLabel *p2_label;
    QPushButton *unset_p2;
    QPushButton *unset_p1;
    QLabel *label_3;
    QComboBox *drawCombo;
    QLabel *type_label;
    QSpinBox *grid_size;
    QLabel *timer_label_1;
    QLabel *timer_label_2;
    QComboBox *color_box;
    QLabel *label_4;
    QWidget *gridLayoutWidget;
    QGridLayout *gridLayout;
    QSpinBox *radius_box;
    QSpinBox *radius_box_2;
    QLabel *radius_label;
    QFrame *line_2;
    QPushButton *set_np;
    QPushButton *draw_2;
    QComboBox *drawCombo_2;
    QPushButton *draw_3;
    QPushButton *unset_np;
    QPushButton *transform_b;
    QComboBox *transform_m;
    QDoubleSpinBox *scale_y;
    QDoubleSpinBox *scale_x;
    QComboBox *clip_type;
    QPushButton *clipping;
    QPushButton *draw_window;
    QPushButton *window_point;
    QFrame *line_3;
    QFrame *line_4;
    QPushButton *unset_window;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1520, 750);
        MainWindow->setStyleSheet(QLatin1String("background:rgb(170, 170, 127);\n"
"color:rgb(85, 0, 255)"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        line = new QFrame(centralwidget);
        line->setObjectName(QStringLiteral("line"));
        line->setGeometry(QRect(1250, 0, 16, 771));
        QFont font;
        font.setPointSize(16);
        font.setBold(true);
        font.setWeight(75);
        line->setFont(font);
        line->setStyleSheet(QLatin1String("selection-color: rgb(0, 170, 127);\n"
"background-color: rgb(0, 170, 0);"));
        line->setFrameShape(QFrame::VLine);
        line->setFrameShadow(QFrame::Sunken);
        draw = new QPushButton(centralwidget);
        draw->setObjectName(QStringLiteral("draw"));
        draw->setGeometry(QRect(1280, 250, 111, 31));
        QFont font1;
        font1.setPointSize(10);
        font1.setBold(true);
        font1.setWeight(75);
        draw->setFont(font1);
        draw->setStyleSheet(QLatin1String("background:rgb(0, 170, 255);\n"
"color:rgb(0, 0, 127)"));
        reset = new QPushButton(centralwidget);
        reset->setObjectName(QStringLiteral("reset"));
        reset->setGeometry(QRect(1280, 290, 111, 31));
        reset->setFont(font1);
        reset->setStyleSheet(QLatin1String("background:rgb(0, 170, 255);\n"
"color:rgb(0, 0, 127)"));
        frame = new my_label(centralwidget);
        frame->setObjectName(QStringLiteral("frame"));
        frame->setEnabled(true);
        frame->setGeometry(QRect(20, 30, 1230, 730));
        frame->setMouseTracking(true);
        frame->setAutoFillBackground(false);
        frame->setStyleSheet(QStringLiteral("background-color: rgb(30, 30, 30) "));
        frame->setFrameShape(QFrame::Box);
        frame->setFrameShadow(QFrame::Plain);
        frame->setLineWidth(3);
        show_axes = new QCheckBox(centralwidget);
        show_axes->setObjectName(QStringLiteral("show_axes"));
        show_axes->setGeometry(QRect(1280, 160, 91, 22));
        show_axes->setFont(font1);
        show_axes->setStyleSheet(QLatin1String("QCheckBox::indicator {\n"
"    background: none;\n"
"}"));
        label = new QLabel(centralwidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(1280, 0, 111, 20));
        label->setFont(font1);
        mouse_position = new QLabel(centralwidget);
        mouse_position->setObjectName(QStringLiteral("mouse_position"));
        mouse_position->setGeometry(QRect(1270, 20, 131, 25));
        mouse_position->setFont(font1);
        mouse_position->setStyleSheet(QLatin1String("background:rgb(255, 255, 255);\n"
"color:rgb(255, 0, 255)"));
        mouse_position->setFrameShape(QFrame::Panel);
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(1410, 0, 111, 16));
        label_2->setFont(font1);
        locked_position = new QLabel(centralwidget);
        locked_position->setObjectName(QStringLiteral("locked_position"));
        locked_position->setGeometry(QRect(1400, 20, 121, 25));
        locked_position->setFont(font1);
        locked_position->setStyleSheet(QLatin1String("background:rgb(255, 255, 255);\n"
"color:rgb(255, 0, 255)"));
        locked_position->setFrameShape(QFrame::Panel);
        set_p1 = new QPushButton(centralwidget);
        set_p1->setObjectName(QStringLiteral("set_p1"));
        set_p1->setGeometry(QRect(1280, 50, 101, 31));
        set_p1->setFont(font1);
        set_p1->setStyleSheet(QLatin1String("background:rgb(0, 170, 255);\n"
"color:rgb(0, 0, 127)"));
        set_p2 = new QPushButton(centralwidget);
        set_p2->setObjectName(QStringLiteral("set_p2"));
        set_p2->setEnabled(true);
        set_p2->setGeometry(QRect(1280, 90, 101, 31));
        set_p2->setFont(font1);
        set_p2->setStyleSheet(QLatin1String("background:rgb(0, 170, 255);\n"
"color:rgb(0, 0, 127)"));
        p1_label = new QLabel(centralwidget);
        p1_label->setObjectName(QStringLiteral("p1_label"));
        p1_label->setGeometry(QRect(1410, 50, 101, 31));
        p1_label->setFont(font1);
        p1_label->setStyleSheet(QLatin1String("background:rgb(255, 255, 255);\n"
"color:rgb(255, 0, 255)"));
        p1_label->setFrameShape(QFrame::Box);
        p2_label = new QLabel(centralwidget);
        p2_label->setObjectName(QStringLiteral("p2_label"));
        p2_label->setGeometry(QRect(1410, 90, 101, 31));
        p2_label->setFont(font1);
        p2_label->setStyleSheet(QLatin1String("background:rgb(255, 255, 255);\n"
"color:rgb(255, 0, 255)"));
        p2_label->setFrameShape(QFrame::Box);
        unset_p2 = new QPushButton(centralwidget);
        unset_p2->setObjectName(QStringLiteral("unset_p2"));
        unset_p2->setGeometry(QRect(1410, 130, 101, 31));
        unset_p2->setFont(font1);
        unset_p2->setStyleSheet(QLatin1String("background:rgb(0, 170, 255);\n"
"color:rgb(0, 0, 127)"));
        unset_p1 = new QPushButton(centralwidget);
        unset_p1->setObjectName(QStringLiteral("unset_p1"));
        unset_p1->setEnabled(true);
        unset_p1->setGeometry(QRect(1280, 130, 101, 31));
        unset_p1->setFont(font1);
        unset_p1->setStyleSheet(QLatin1String("background:rgb(0, 170, 255);\n"
"color:rgb(0, 0, 127)"));
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(1420, 160, 61, 20));
        label_3->setFont(font1);
        drawCombo = new QComboBox(centralwidget);
        drawCombo->setObjectName(QStringLiteral("drawCombo"));
        drawCombo->setGeometry(QRect(1270, 220, 241, 22));
        drawCombo->setFont(font1);
        drawCombo->setLayoutDirection(Qt::LeftToRight);
        type_label = new QLabel(centralwidget);
        type_label->setObjectName(QStringLiteral("type_label"));
        type_label->setGeometry(QRect(430, 0, 431, 30));
        QFont font2;
        font2.setPointSize(20);
        font2.setBold(true);
        font2.setItalic(true);
        font2.setUnderline(false);
        font2.setWeight(75);
        font2.setStrikeOut(false);
        font2.setKerning(false);
        type_label->setFont(font2);
        type_label->setAlignment(Qt::AlignCenter);
        grid_size = new QSpinBox(centralwidget);
        grid_size->setObjectName(QStringLiteral("grid_size"));
        grid_size->setGeometry(QRect(1400, 180, 105, 24));
        grid_size->setFont(font1);
        grid_size->setStyleSheet(QLatin1String("background:rgb(0,0,0);\n"
"color:rgb(170, 255, 255)"));
        timer_label_1 = new QLabel(centralwidget);
        timer_label_1->setObjectName(QStringLiteral("timer_label_1"));
        timer_label_1->setGeometry(QRect(1280, 660, 231, 20));
        QFont font3;
        font3.setPointSize(9);
        font3.setBold(true);
        font3.setWeight(75);
        timer_label_1->setFont(font3);
        timer_label_1->setStyleSheet(QStringLiteral("color:rgb(255, 0, 255) "));
        timer_label_2 = new QLabel(centralwidget);
        timer_label_2->setObjectName(QStringLiteral("timer_label_2"));
        timer_label_2->setGeometry(QRect(1280, 690, 231, 20));
        timer_label_2->setFont(font3);
        timer_label_2->setStyleSheet(QStringLiteral("color:rgb(255, 0, 255) "));
        color_box = new QComboBox(centralwidget);
        color_box->setObjectName(QStringLiteral("color_box"));
        color_box->setGeometry(QRect(1280, 200, 101, 21));
        color_box->setFont(font1);
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(1280, 180, 91, 21));
        label_4->setFont(font1);
        gridLayoutWidget = new QWidget(centralwidget);
        gridLayoutWidget->setObjectName(QStringLiteral("gridLayoutWidget"));
        gridLayoutWidget->setGeometry(QRect(1400, 250, 111, 80));
        gridLayout = new QGridLayout(gridLayoutWidget);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        radius_box = new QSpinBox(gridLayoutWidget);
        radius_box->setObjectName(QStringLiteral("radius_box"));
        radius_box->setFont(font1);

        gridLayout->addWidget(radius_box, 2, 0, 1, 1);

        radius_box_2 = new QSpinBox(gridLayoutWidget);
        radius_box_2->setObjectName(QStringLiteral("radius_box_2"));
        radius_box_2->setFont(font1);

        gridLayout->addWidget(radius_box_2, 3, 0, 1, 1);

        radius_label = new QLabel(gridLayoutWidget);
        radius_label->setObjectName(QStringLiteral("radius_label"));
        radius_label->setFont(font1);

        gridLayout->addWidget(radius_label, 1, 0, 1, 1);

        gridLayout->setRowStretch(0, 1);
        gridLayout->setRowStretch(1, 1);
        gridLayout->setRowStretch(2, 1);
        line_2 = new QFrame(centralwidget);
        line_2->setObjectName(QStringLiteral("line_2"));
        line_2->setGeometry(QRect(1270, 330, 251, 20));
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);
        set_np = new QPushButton(centralwidget);
        set_np->setObjectName(QStringLiteral("set_np"));
        set_np->setEnabled(true);
        set_np->setGeometry(QRect(1270, 350, 111, 31));
        set_np->setFont(font1);
        set_np->setStyleSheet(QLatin1String("background:rgb(0, 170, 255);\n"
"color:rgb(0, 0, 127)"));
        draw_2 = new QPushButton(centralwidget);
        draw_2->setObjectName(QStringLiteral("draw_2"));
        draw_2->setGeometry(QRect(1270, 390, 111, 31));
        draw_2->setFont(font1);
        draw_2->setStyleSheet(QLatin1String("background:rgb(0, 170, 255);\n"
"color:rgb(0, 0, 127)"));
        drawCombo_2 = new QComboBox(centralwidget);
        drawCombo_2->setObjectName(QStringLiteral("drawCombo_2"));
        drawCombo_2->setGeometry(QRect(1270, 430, 241, 22));
        drawCombo_2->setFont(font1);
        drawCombo_2->setLayoutDirection(Qt::LeftToRight);
        draw_3 = new QPushButton(centralwidget);
        draw_3->setObjectName(QStringLiteral("draw_3"));
        draw_3->setGeometry(QRect(1390, 390, 111, 31));
        draw_3->setFont(font1);
        draw_3->setStyleSheet(QLatin1String("background:rgb(0, 170, 255);\n"
"color:rgb(0, 0, 127)"));
        unset_np = new QPushButton(centralwidget);
        unset_np->setObjectName(QStringLiteral("unset_np"));
        unset_np->setEnabled(true);
        unset_np->setGeometry(QRect(1390, 350, 111, 31));
        unset_np->setFont(font1);
        unset_np->setStyleSheet(QLatin1String("background:rgb(0, 170, 255);\n"
"color:rgb(0, 0, 127)"));
        transform_b = new QPushButton(centralwidget);
        transform_b->setObjectName(QStringLiteral("transform_b"));
        transform_b->setGeometry(QRect(1400, 500, 111, 30));
        transform_b->setFont(font1);
        transform_b->setStyleSheet(QLatin1String("background:rgb(0, 170, 255);\n"
"color:rgb(0, 0, 127)"));
        transform_m = new QComboBox(centralwidget);
        transform_m->setObjectName(QStringLiteral("transform_m"));
        transform_m->setGeometry(QRect(1270, 500, 121, 30));
        transform_m->setFont(font1);
        transform_m->setLayoutDirection(Qt::LeftToRight);
        scale_y = new QDoubleSpinBox(centralwidget);
        scale_y->setObjectName(QStringLiteral("scale_y"));
        scale_y->setGeometry(QRect(1390, 470, 120, 25));
        scale_y->setFont(font1);
        scale_y->setStyleSheet(QLatin1String("background:rgb(0,0,0);\n"
"color:rgb(170, 255, 255)"));
        scale_y->setDecimals(1);
        scale_y->setMinimum(-1000);
        scale_y->setMaximum(1000);
        scale_y->setSingleStep(0.2);
        scale_y->setValue(1);
        scale_x = new QDoubleSpinBox(centralwidget);
        scale_x->setObjectName(QStringLiteral("scale_x"));
        scale_x->setGeometry(QRect(1270, 470, 120, 25));
        scale_x->setFont(font1);
        scale_x->setStyleSheet(QLatin1String("background:rgb(0,0,0);\n"
"color:rgb(170, 255, 255)"));
        scale_x->setDecimals(1);
        scale_x->setMinimum(-1000);
        scale_x->setMaximum(1000);
        scale_x->setSingleStep(0.2);
        scale_x->setValue(1);
        clip_type = new QComboBox(centralwidget);
        clip_type->setObjectName(QStringLiteral("clip_type"));
        clip_type->setGeometry(QRect(1270, 590, 121, 30));
        clip_type->setFont(font1);
        clip_type->setLayoutDirection(Qt::LeftToRight);
        clipping = new QPushButton(centralwidget);
        clipping->setObjectName(QStringLiteral("clipping"));
        clipping->setGeometry(QRect(1270, 620, 111, 30));
        clipping->setFont(font1);
        clipping->setStyleSheet(QLatin1String("background:rgb(0, 170, 255);\n"
"color:rgb(0, 0, 127)"));
        draw_window = new QPushButton(centralwidget);
        draw_window->setObjectName(QStringLiteral("draw_window"));
        draw_window->setGeometry(QRect(1400, 560, 111, 30));
        draw_window->setFont(font1);
        draw_window->setStyleSheet(QLatin1String("background:rgb(0, 170, 255);\n"
"color:rgb(0, 0, 127)"));
        window_point = new QPushButton(centralwidget);
        window_point->setObjectName(QStringLiteral("window_point"));
        window_point->setEnabled(true);
        window_point->setGeometry(QRect(1270, 560, 111, 31));
        window_point->setFont(font1);
        window_point->setStyleSheet(QLatin1String("background:rgb(0, 170, 255);\n"
"color:rgb(0, 0, 127)"));
        line_3 = new QFrame(centralwidget);
        line_3->setObjectName(QStringLiteral("line_3"));
        line_3->setGeometry(QRect(1270, 450, 251, 20));
        line_3->setFrameShape(QFrame::HLine);
        line_3->setFrameShadow(QFrame::Sunken);
        line_4 = new QFrame(centralwidget);
        line_4->setObjectName(QStringLiteral("line_4"));
        line_4->setGeometry(QRect(1270, 540, 251, 20));
        line_4->setFrameShape(QFrame::HLine);
        line_4->setFrameShadow(QFrame::Sunken);
        unset_window = new QPushButton(centralwidget);
        unset_window->setObjectName(QStringLiteral("unset_window"));
        unset_window->setEnabled(true);
        unset_window->setGeometry(QRect(1400, 590, 111, 31));
        unset_window->setFont(font1);
        unset_window->setStyleSheet(QLatin1String("background:rgb(0, 170, 255);\n"
"color:rgb(0, 0, 127)"));
        MainWindow->setCentralWidget(centralwidget);
        label_4->raise();
        line->raise();
        draw->raise();
        reset->raise();
        frame->raise();
        show_axes->raise();
        label->raise();
        mouse_position->raise();
        label_2->raise();
        locked_position->raise();
        set_p1->raise();
        set_p2->raise();
        p1_label->raise();
        p2_label->raise();
        unset_p2->raise();
        unset_p1->raise();
        label_3->raise();
        drawCombo->raise();
        type_label->raise();
        timer_label_1->raise();
        timer_label_2->raise();
        color_box->raise();
        gridLayoutWidget->raise();
        grid_size->raise();
        line_2->raise();
        set_np->raise();
        draw_2->raise();
        drawCombo_2->raise();
        draw_3->raise();
        unset_np->raise();
        transform_b->raise();
        transform_m->raise();
        scale_y->raise();
        scale_x->raise();
        clip_type->raise();
        clipping->raise();
        draw_window->raise();
        window_point->raise();
        line_3->raise();
        line_4->raise();
        unset_window->raise();
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 1520, 21));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0));
        draw->setText(QApplication::translate("MainWindow", "Draw", 0));
        reset->setText(QApplication::translate("MainWindow", "reset", 0));
        frame->setText(QString());
        show_axes->setText(QApplication::translate("MainWindow", "show axes", 0));
        label->setText(QApplication::translate("MainWindow", "Current position", 0));
        mouse_position->setText(QApplication::translate("MainWindow", "hello", 0));
        label_2->setText(QApplication::translate("MainWindow", "Locked Position", 0));
        locked_position->setText(QString());
        set_p1->setText(QApplication::translate("MainWindow", "Set Point 1", 0));
        set_p2->setText(QApplication::translate("MainWindow", "Set Point 2", 0));
        p1_label->setText(QApplication::translate("MainWindow", "Not set", 0));
        p2_label->setText(QApplication::translate("MainWindow", "Not set", 0));
        unset_p2->setText(QApplication::translate("MainWindow", "Unset Point 2", 0));
        unset_p1->setText(QApplication::translate("MainWindow", "Unset Point 1", 0));
        label_3->setText(QApplication::translate("MainWindow", "Grid Size", 0));
        drawCombo->clear();
        drawCombo->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "Select Drawing type", 0)
         << QApplication::translate("MainWindow", "DDA Line Drawing", 0)
         << QApplication::translate("MainWindow", "Bresenham Line Drawing", 0)
         << QApplication::translate("MainWindow", "Bresenham circle", 0)
         << QApplication::translate("MainWindow", "Polar circle", 0)
         << QApplication::translate("MainWindow", "Parametric circle", 0)
         << QApplication::translate("MainWindow", "Bresenham Ellipse", 0)
        );
        type_label->setText(QString());
        timer_label_1->setText(QString());
        timer_label_2->setText(QString());
        color_box->clear();
        color_box->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "red", 0)
         << QApplication::translate("MainWindow", "blue", 0)
         << QApplication::translate("MainWindow", "green", 0)
        );
        label_4->setText(QApplication::translate("MainWindow", "select color", 0));
        radius_label->setText(QApplication::translate("MainWindow", "Radius", 0));
        set_np->setText(QApplication::translate("MainWindow", "Add point", 0));
        draw_2->setText(QApplication::translate("MainWindow", "Draw Polygon", 0));
        drawCombo_2->clear();
        drawCombo_2->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "Select Filling type", 0)
         << QApplication::translate("MainWindow", "Flood fill", 0)
         << QApplication::translate("MainWindow", "Scan fill", 0)
         << QApplication::translate("MainWindow", "Boundary fill", 0)
        );
        draw_3->setText(QApplication::translate("MainWindow", "Fill", 0));
        unset_np->setText(QApplication::translate("MainWindow", "Remove Points", 0));
        transform_b->setText(QApplication::translate("MainWindow", "Transform", 0));
        transform_m->clear();
        transform_m->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "Transformation", 0)
         << QApplication::translate("MainWindow", "Scalling", 0)
         << QApplication::translate("MainWindow", "Translation", 0)
         << QApplication::translate("MainWindow", "Rotation", 0)
         << QApplication::translate("MainWindow", "Reflection", 0)
         << QApplication::translate("MainWindow", "Sharing", 0)
        );
        clip_type->clear();
        clip_type->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "Clipping", 0)
         << QApplication::translate("MainWindow", "Line clipping", 0)
         << QApplication::translate("MainWindow", "Polygon clipping", 0)
        );
        clipping->setText(QApplication::translate("MainWindow", "CLIP", 0));
        draw_window->setText(QApplication::translate("MainWindow", "Draw Window", 0));
        window_point->setText(QApplication::translate("MainWindow", "Window Point", 0));
        unset_window->setText(QApplication::translate("MainWindow", "Reset Window", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
